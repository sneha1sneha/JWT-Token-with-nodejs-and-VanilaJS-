console.log("h")
    fetch('http://localhost:8080/getemp')
       .then(res => console.log(res.json()))
        
       .then(result=>console.log(result))
    //     )
 


